# Signalroom AI Trading Dashboard

Signalroom is a Telegram Mini App-compatible AI crypto dashboard for BTC/USDT market reads and safe paper trading.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/ai-trading-dashboard/src/` — React/Vite mobile-first dashboard, portfolio, history, settings, and shared trading UI.
- `artifacts/api-server/src/routes/trading.ts` — Telegram session bootstrap, market data, AI signal, portfolio, and paper trade APIs.
- `lib/api-spec/openapi.yaml` — source-of-truth API contract; regenerate clients after changes.
- `lib/db/src/schema/trading.ts` — PostgreSQL/Drizzle tables for Telegram users and paper trades.

## Architecture decisions

- Market and SMC signal data come from live Yahoo Finance OHLC reference data and deterministic analysis rules; no exchange trading API is connected.
- Telegram authentication accepts Mini App user payloads and uses a signed HTTP-only session cookie.
- Symbols retain the user-facing `BTC/USDT` form, with server routes supporting slash-separated path values.
- Portfolio and PnL are calculated from persisted paper trades and current reference prices.

## Product

The app provides a BTC/USDT dashboard, crypto watchlist, interactive reference chart, BUY/SELL/WAIT AI read with confidence and risk levels, paper trade creation and closing, portfolio metrics, trade history, and Telegram profile/session status. It never executes real trades.

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- Use the exact managed workflows for the API and web artifact; the API is served under `/api`.
- Run `pnpm --filter @workspace/api-spec run codegen` after OpenAPI changes, then `pnpm run typecheck:libs` if the generated api-zod barrel needs reconciliation.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
