---
name: Generated API Zod barrel
description: Orval-generated path parameter schemas can collide with generated TypeScript parameter types in the api-zod barrel.
---

When Orval generates a Zod schema and a TypeScript type with the same name for a path parameter, export the generated Zod API module without wildcard-exporting generated types from the package barrel.

**Why:** The collision happens during the workspace library typecheck after codegen, even though Orval itself completes successfully.

**How to apply:** If codegen starts failing with TS2308 duplicate exports in `lib/api-zod`, check the barrel before changing the OpenAPI contract; the server only needs the generated Zod schemas for route validation.