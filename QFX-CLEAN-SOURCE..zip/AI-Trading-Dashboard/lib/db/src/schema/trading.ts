import { createInsertSchema } from "drizzle-zod";
import { integer, numeric, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const telegramUsersTable = pgTable("telegram_users", {
  id: serial("id").primaryKey(),
  telegramId: text("telegram_id").notNull().unique(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name"),
  username: text("username"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const paperTradesTable = pgTable("paper_trades", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => telegramUsersTable.id),
  symbol: text("symbol").notNull(),
  side: text("side").notNull(),
  quantity: numeric("quantity", { precision: 24, scale: 8 }).notNull(),
  entryPrice: numeric("entry_price", { precision: 24, scale: 8 }).notNull(),
  stopLoss: numeric("stop_loss", { precision: 24, scale: 8 }),
  takeProfit: numeric("take_profit", { precision: 24, scale: 8 }),
  exitPrice: numeric("exit_price", { precision: 24, scale: 8 }),
  pnl: numeric("pnl", { precision: 24, scale: 8 }),
  status: text("status").notNull().default("open"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  closedAt: timestamp("closed_at", { withTimezone: true }),
});

export const insertTelegramUserSchema = createInsertSchema(telegramUsersTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertTelegramUser = z.infer<typeof insertTelegramUserSchema>;
export type TelegramUser = typeof telegramUsersTable.$inferSelect;

export const insertPaperTradeSchema = createInsertSchema(paperTradesTable).omit({
  id: true,
  createdAt: true,
  closedAt: true,
});
export type InsertPaperTrade = z.infer<typeof insertPaperTradeSchema>;
export type PaperTrade = typeof paperTradesTable.$inferSelect;