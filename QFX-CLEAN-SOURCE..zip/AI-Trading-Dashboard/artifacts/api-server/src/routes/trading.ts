import crypto from "node:crypto";
import { Router, type IRouter, type Request } from "express";
import cookieParser from "cookie-parser";
import { and, desc, eq } from "drizzle-orm";
import {
  AuthenticateTelegramBody,
  AuthenticateTelegramResponse,
  ClosePaperTradeParams,
  ClosePaperTradeResponse,
  CreatePaperTradeBody,
  CreatePaperTradeResponse,
  GetAuthSessionResponse,
  GetDashboardResponse,
  GetMarketChartParams,
  GetMarketChartQueryParams,
  GetMarketChartResponse,
  GetPortfolioResponse,
  GetTradingSignalParams,
  GetTradingSignalResponse,
  ListMarketsResponse,
  ListTradesQueryParams,
  ListTradesResponse,
} from "@workspace/api-zod";
import { db, paperTradesTable, telegramUsersTable } from "@workspace/db";
import { getAllMarketBundles, getMarketBundle, marketFromBundle } from "../lib/market-data";
import { analyzeTimeframe, buildSMCSignal, type Timeframe } from "../lib/smc";

const router: IRouter = Router();
const SESSION_COOKIE = "telegram_session";
const sessionSecret = process.env.SESSION_SECRET ?? "local-paper-trading-session";

type User = typeof telegramUsersTable.$inferSelect;
type Trade = typeof paperTradesTable.$inferSelect;

function signedSession(userId: number): string {
  const payload = String(userId);
  const signature = crypto.createHmac("sha256", sessionSecret).update(payload).digest("hex");
  return `${payload}.${signature}`;
}

function sessionUserId(req: Request): number | null {
  const value = req.signedCookies?.[SESSION_COOKIE];
  if (typeof value !== "string" || !/^\d+\.[a-f0-9]{64}$/.test(value)) return null;
  const [id, signature] = value.split(".");
  const expected = crypto.createHmac("sha256", sessionSecret).update(id).digest("hex");
  return crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected)) ? Number(id) : null;
}

async function getUser(req: Request): Promise<User> {
  const id = sessionUserId(req);
  if (id) {
    const [user] = await db.select().from(telegramUsersTable).where(eq(telegramUsersTable.id, id)).limit(1);
    if (user) return user;
  }
  return upsertUser({ id: 900001, firstName: "Demo", lastName: "Trader", username: "paper_trader" });
}

async function upsertUser(input: { id: number; firstName: string; lastName?: string | null; username?: string | null }): Promise<User> {
  const telegramId = String(input.id);
  const [existing] = await db.select().from(telegramUsersTable).where(eq(telegramUsersTable.telegramId, telegramId)).limit(1);
  if (existing) {
    const [updated] = await db.update(telegramUsersTable)
      .set({ firstName: input.firstName, lastName: input.lastName ?? null, username: input.username ?? null, updatedAt: new Date() })
      .where(eq(telegramUsersTable.id, existing.id))
      .returning();
    return updated ?? existing;
  }
  const [created] = await db.insert(telegramUsersTable).values({
    telegramId,
    firstName: input.firstName,
    lastName: input.lastName ?? null,
    username: input.username ?? null,
  }).returning();
  return created;
}

async function markets() {
  return (await getAllMarketBundles()).map(marketFromBundle);
}

async function marketFor(symbol: string) {
  return marketFromBundle(await getMarketBundle(symbol));
}

async function signalFor(symbol: string) {
  const bundle = await getMarketBundle(symbol);
  const timeframes: Timeframe[] = ["4H", "1H", "15M"];
  const analyses = timeframes.map((timeframe) => analyzeTimeframe(bundle.candles[timeframe], timeframe));
  return buildSMCSignal(
    bundle.definition.symbol,
    bundle.definition.name,
    bundle.definition.source,
    bundle.dataAsOf,
    analyses,
    bundle.latest,
  );
}

function tradeResponse(trade: Trade) {
  return {
    id: trade.id,
    symbol: trade.symbol,
    side: trade.side,
    quantity: Number(trade.quantity),
    entryPrice: Number(trade.entryPrice),
    exitPrice: trade.exitPrice == null ? null : Number(trade.exitPrice),
    pnl: trade.pnl == null ? null : Number(trade.pnl),
    status: trade.status,
    createdAt: trade.createdAt,
    closedAt: trade.closedAt,
  };
}

async function tradesFor(userId: number): Promise<Trade[]> {
  return db.select().from(paperTradesTable).where(eq(paperTradesTable.userId, userId)).orderBy(desc(paperTradesTable.createdAt));
}

async function portfolioFor(userId: number) {
  const trades = await tradesFor(userId);
  const currentMarkets = await markets();
  const realized = trades.filter((trade) => trade.status === "closed").reduce((sum, trade) => sum + Number(trade.pnl ?? 0), 0);
  const unrealized = trades.filter((trade) => trade.status === "open").reduce((sum, trade) => {
    const current = currentMarkets.find((market) => market.symbol === trade.symbol)?.price ?? Number(trade.entryPrice);
    const entry = Number(trade.entryPrice);
    const quantity = Number(trade.quantity);
    return sum + (trade.side === "BUY" ? current - entry : entry - current) * quantity;
  }, 0);
  const closed = trades.filter((trade) => trade.status === "closed");
  const winners = closed.filter((trade) => Number(trade.pnl ?? 0) > 0).length;
  const pnl = realized + unrealized;
  return {
    balance: 10000,
    equity: Number((10000 + pnl).toFixed(2)),
    pnl: Number(pnl.toFixed(2)),
    pnlPercent: Number((pnl / 100).toFixed(2)),
    winRate: closed.length ? Number(((winners / closed.length) * 100).toFixed(1)) : 0,
    openPositions: trades.filter((trade) => trade.status === "open").length,
    totalTrades: trades.length,
  };
}

async function candles(symbol: string, interval: string) {
  const bundle = await getMarketBundle(symbol);
  const timeframe = interval as Timeframe;
  const series = bundle.candles[timeframe] ?? bundle.candles["4H"];
  return series.map((candle) => ({
    timestamp: candle.timestamp,
    open: candle.open,
    high: candle.high,
    low: candle.low,
    close: candle.close,
    volume: candle.volume,
  }));
}

router.get("/auth/session", async (req, res): Promise<void> => {
  const id = sessionUserId(req);
  if (!id) {
    res.json(GetAuthSessionResponse.parse({ authenticated: false, user: null }));
    return;
  }
  const [user] = await db.select().from(telegramUsersTable).where(eq(telegramUsersTable.id, id)).limit(1);
  if (!user) {
    res.json(GetAuthSessionResponse.parse({ authenticated: false, user: null }));
    return;
  }
  res.json(GetAuthSessionResponse.parse({
    authenticated: true,
    user: { id: Number(user.telegramId), firstName: user.firstName, lastName: user.lastName, username: user.username },
  }));
});

router.post("/auth/telegram", async (req, res): Promise<void> => {
  const parsed = AuthenticateTelegramBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(401).json({ error: "A Telegram user payload is required" });
    return;
  }
  const user = await upsertUser(parsed.data.user);
  res.cookie(SESSION_COOKIE, signedSession(user.id), { httpOnly: true, sameSite: "lax", signed: true, maxAge: 7 * 24 * 60 * 60 * 1000 });
  res.json(AuthenticateTelegramResponse.parse({
    authenticated: true,
    user: { id: Number(user.telegramId), firstName: user.firstName, lastName: user.lastName, username: user.username },
  }));
});

router.get("/markets", async (_req, res): Promise<void> => {
  try {
    res.json(ListMarketsResponse.parse(await markets()));
  } catch (error) {
    res.status(503).json({ error: error instanceof Error ? error.message : "Live market data is unavailable" });
  }
});

router.get(["/markets/:symbol/chart", "/markets/:base/:quote/chart"], async (req, res): Promise<void> => {
  const symbol = req.params.symbol ?? `${req.params.base}/${req.params.quote}`;
  const params = GetMarketChartParams.safeParse({ symbol });
  const query = GetMarketChartQueryParams.safeParse(req.query);
  if (!params.success || !query.success) {
    res.status(400).json({ error: "Invalid chart parameters" });
    return;
  }
  try {
    res.json(GetMarketChartResponse.parse(await candles(params.data.symbol, query.data.interval)));
  } catch (error) {
    res.status(503).json({ error: error instanceof Error ? error.message : "Live market data is unavailable" });
  }
});

router.get(["/signals/:symbol", "/signals/:base/:quote"], async (req, res): Promise<void> => {
  const symbol = req.params.symbol ?? `${req.params.base}/${req.params.quote}`;
  const params = GetTradingSignalParams.safeParse({ symbol });
  if (!params.success) {
    res.status(400).json({ error: "Invalid market symbol" });
    return;
  }
  try {
    res.json(GetTradingSignalResponse.parse(await signalFor(params.data.symbol)));
  } catch (error) {
    res.status(503).json({ error: error instanceof Error ? error.message : "Live market data is unavailable" });
  }
});

router.get("/portfolio", async (req, res): Promise<void> => {
  res.json(GetPortfolioResponse.parse(await portfolioFor((await getUser(req)).id)));
});

router.get("/trades", async (req, res): Promise<void> => {
  const query = ListTradesQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: "Invalid trade filter" });
    return;
  }
  const trades = await tradesFor((await getUser(req)).id);
  const filtered = query.data.status === "all" ? trades : trades.filter((trade) => trade.status === query.data.status);
  res.json(ListTradesResponse.parse(filtered.map(tradeResponse)));
});

router.post("/trades", async (req, res): Promise<void> => {
  const parsed = CreatePaperTradeBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const user = await getUser(req);
  const [trade] = await db.insert(paperTradesTable).values({
    userId: user.id,
    symbol: parsed.data.symbol,
    side: parsed.data.side,
    quantity: String(parsed.data.quantity),
    entryPrice: String(parsed.data.entryPrice),
    stopLoss: parsed.data.stopLoss == null ? null : String(parsed.data.stopLoss),
    takeProfit: parsed.data.takeProfit == null ? null : String(parsed.data.takeProfit),
  }).returning();
  res.status(201).json(CreatePaperTradeResponse.parse(tradeResponse(trade)));
});

router.post("/trades/:id/close", async (req, res): Promise<void> => {
  const params = ClosePaperTradeParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "Invalid trade id" });
    return;
  }
  const user = await getUser(req);
  const [trade] = await db.select().from(paperTradesTable)
    .where(and(eq(paperTradesTable.id, params.data.id), eq(paperTradesTable.userId, user.id))).limit(1);
  if (!trade) {
    res.status(404).json({ error: "Paper trade not found" });
    return;
  }
  if (trade.status === "closed") {
    res.json(ClosePaperTradeResponse.parse(tradeResponse(trade)));
    return;
  }
  let exitPrice: number;
  try {
    exitPrice = (await marketFor(trade.symbol)).price;
  } catch (error) {
    res.status(503).json({ error: error instanceof Error ? error.message : "Live market data is unavailable" });
    return;
  }
  const pnl = (trade.side === "BUY" ? exitPrice - Number(trade.entryPrice) : Number(trade.entryPrice) - exitPrice) * Number(trade.quantity);
  const [closed] = await db.update(paperTradesTable).set({
    status: "closed",
    exitPrice: String(exitPrice),
    pnl: String(pnl),
    closedAt: new Date(),
  }).where(eq(paperTradesTable.id, trade.id)).returning();
  res.json(ClosePaperTradeResponse.parse(tradeResponse(closed)));
});

router.get("/dashboard", async (req, res): Promise<void> => {
  try {
    const user = await getUser(req);
    const marketsList = await markets();
    const trades = await tradesFor(user.id);
    res.json(GetDashboardResponse.parse({
      portfolio: await portfolioFor(user.id),
      featuredMarket: marketsList[0],
      signal: await signalFor("BTC/USDT"),
      markets: marketsList,
      activity: trades.slice(0, 5).map(tradeResponse),
    }));
  } catch (error) {
    res.status(503).json({ error: error instanceof Error ? error.message : "Live market data is unavailable" });
  }
});

export const tradingCookieMiddleware = cookieParser(sessionSecret);
export default router;