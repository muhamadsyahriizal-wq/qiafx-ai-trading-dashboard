export type Timeframe = "4H" | "1H" | "15M";
export type Bias = "bullish" | "bearish" | "neutral";
export type DetectionCategory =
  | "structure"
  | "liquidity"
  | "imbalance"
  | "order_block"
  | "supply_demand"
  | "support_resistance"
  | "displacement";

export interface OHLCV {
  timestamp: Date;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface SMCDetection {
  category: DetectionCategory;
  type: string;
  timeframe: Timeframe;
  status: string;
  price: number;
  price2: number | null;
  evidence: string;
  timestamp: Date;
}

export interface SMCScoreFactor {
  name: string;
  score: number;
  maxScore: number;
  evidence: string;
}

export interface TimeframeAnalysis {
  timeframe: Timeframe;
  bias: Bias;
  score: number;
  detections: SMCDetection[];
}

interface Pivot {
  index: number;
  price: number;
}

function round(value: number, digits = 2): number {
  return Number(value.toFixed(digits));
}

function trueRange(current: OHLCV, previous?: OHLCV): number {
  if (!previous) return current.high - current.low;
  return Math.max(
    current.high - current.low,
    Math.abs(current.high - previous.close),
    Math.abs(current.low - previous.close),
  );
}

function atr(candles: OHLCV[], period = 14): number {
  const ranges = candles.map((candle, index) => trueRange(candle, candles[index - 1]));
  const slice = ranges.slice(-Math.min(period, ranges.length));
  return slice.reduce((sum, value) => sum + value, 0) / Math.max(slice.length, 1);
}

function findPivots(candles: OHLCV[], side: "high" | "low", lookback = 2): Pivot[] {
  const pivots: Pivot[] = [];
  for (let index = lookback; index < candles.length - lookback; index += 1) {
    const value = side === "high" ? candles[index].high : candles[index].low;
    const neighbors = [
      ...candles.slice(index - lookback, index),
      ...candles.slice(index + 1, index + lookback + 1),
    ];
    const isPivot = side === "high"
      ? neighbors.every((candle) => value >= candle.high)
      : neighbors.every((candle) => value <= candle.low);
    if (isPivot) pivots.push({ index, price: value });
  }
  return pivots;
}

function lastPivotBefore(pivots: Pivot[], index: number): Pivot | undefined {
  return [...pivots].reverse().find((pivot) => pivot.index < index);
}

function addDetection(
  detections: SMCDetection[],
  input: Omit<SMCDetection, "price2" | "timestamp"> & { price2?: number | null },
): void {
  detections.push({ ...input, price2: input.price2 ?? null, timestamp: new Date(0) });
}

function previousLevels(candles: OHLCV[]): Array<{ type: string; high: number; low: number }> {
  const daily = new Map<string, OHLCV[]>();
  const weekly = new Map<string, OHLCV[]>();
  for (const candle of candles) {
    const date = candle.timestamp.toISOString().slice(0, 10);
    const week = String(Math.floor(candle.timestamp.getTime() / (7 * 24 * 60 * 60 * 1000)));
    daily.set(date, [...(daily.get(date) ?? []), candle]);
    weekly.set(week, [...(weekly.get(week) ?? []), candle]);
  }
  const dates = [...daily.keys()].sort();
  const weeks = [...weekly.keys()].sort();
  const levels: Array<{ type: string; high: number; low: number }> = [];
  if (dates.length > 1) {
    const candlesForDay = daily.get(dates[dates.length - 2]) ?? [];
    levels.push({
      type: "Previous Day",
      high: Math.max(...candlesForDay.map((candle) => candle.high)),
      low: Math.min(...candlesForDay.map((candle) => candle.low)),
    });
  }
  if (weeks.length > 1) {
    const candlesForWeek = weekly.get(weeks[weeks.length - 2]) ?? [];
    levels.push({
      type: "Previous Week",
      high: Math.max(...candlesForWeek.map((candle) => candle.high)),
      low: Math.min(...candlesForWeek.map((candle) => candle.low)),
    });
  }
  return levels;
}

function statusForZone(
  candles: OHLCV[],
  startIndex: number,
  low: number,
  high: number,
  direction: "bullish" | "bearish",
): string {
  const later = candles.slice(startIndex + 1);
  const mitigated = later.some((candle) => candle.low <= high && candle.high >= low);
  const invalidated = direction === "bullish"
    ? later.some((candle) => candle.close < low)
    : later.some((candle) => candle.close > high);
  if (invalidated) return "Invalidated";
  if (mitigated) return "Mitigated";
  return "Fresh";
}

function structureDetections(
  candles: OHLCV[],
  timeframe: Timeframe,
  atrValue: number,
): { detections: SMCDetection[]; highs: Pivot[]; lows: Pivot[]; bias: Bias } {
  const detections: SMCDetection[] = [];
  const highs = findPivots(candles, "high");
  const lows = findPivots(candles, "low");
  let previousHigh: Pivot | undefined;
  let previousLow: Pivot | undefined;
  const labels: string[] = [];

  for (const pivot of highs) {
    if (previousHigh) {
      const type = pivot.price > previousHigh.price ? "HH" : "LH";
      labels.push(type);
      addDetection(detections, {
        category: "structure",
        type,
        timeframe,
        status: "Confirmed",
        price: round(pivot.price),
        evidence: `${type} at ${round(pivot.price)} versus prior swing high ${round(previousHigh.price)}`,
      });
    }
    previousHigh = pivot;
  }
  for (const pivot of lows) {
    if (previousLow) {
      const type = pivot.price > previousLow.price ? "HL" : "LL";
      labels.push(type);
      addDetection(detections, {
        category: "structure",
        type,
        timeframe,
        status: "Confirmed",
        price: round(pivot.price),
        evidence: `${type} at ${round(pivot.price)} versus prior swing low ${round(previousLow.price)}`,
      });
    }
    previousLow = pivot;
  }

  const last = candles[candles.length - 1];
  const lastHigh = lastPivotBefore(highs, candles.length);
  const lastLow = lastPivotBefore(lows, candles.length);
  const trendBullish = labels.slice(-4).filter((label) => label === "HH" || label === "HL").length >= 2;
  const trendBearish = labels.slice(-4).filter((label) => label === "LH" || label === "LL").length >= 2;
  const bias: Bias = trendBullish && !trendBearish ? "bullish" : trendBearish && !trendBullish ? "bearish" : "neutral";
  const body = Math.abs(last.close - last.open);
  const displacement = body >= atrValue * 1.5;

  if (lastHigh && last.close > lastHigh.price) {
    const type = bias === "bearish" ? "CHoCH" : "BOS";
    addDetection(detections, {
      category: "structure",
      type,
      timeframe,
      status: "Confirmed",
      price: round(last.close),
      evidence: `Close broke above swing high ${round(lastHigh.price)}`,
    });
    if (displacement) {
      addDetection(detections, {
        category: "structure",
        type: "MSS",
        timeframe,
        status: "Confirmed",
        price: round(last.close),
        evidence: `Displacement body ${round(body)} is at least 1.5 ATR and broke structure`,
      });
    }
  }
  if (lastLow && last.close < lastLow.price) {
    const type = bias === "bullish" ? "CHoCH" : "BOS";
    addDetection(detections, {
      category: "structure",
      type,
      timeframe,
      status: "Confirmed",
      price: round(last.close),
      evidence: `Close broke below swing low ${round(lastLow.price)}`,
    });
    if (displacement) {
      addDetection(detections, {
        category: "structure",
        type: "MSS",
        timeframe,
        status: "Confirmed",
        price: round(last.close),
        evidence: `Displacement body ${round(body)} is at least 1.5 ATR and broke structure`,
      });
    }
  }
  return { detections, highs, lows, bias };
}

function liquidityDetections(
  candles: OHLCV[],
  timeframe: Timeframe,
  highs: Pivot[],
  lows: Pivot[],
  atrValue: number,
): SMCDetection[] {
  const detections: SMCDetection[] = [];
  const tolerance = atrValue * 0.2;
  const lastHigh = highs[highs.length - 1];
  const lastLow = lows[lows.length - 1];
  if (lastHigh) {
    addDetection(detections, {
      category: "liquidity",
      type: "Buy-side liquidity",
      timeframe,
      status: "Resting above swing high",
      price: round(lastHigh.price),
      evidence: "Swing highs are treated as observable buy-side liquidity references",
    });
  }
  if (lastLow) {
    addDetection(detections, {
      category: "liquidity",
      type: "Sell-side liquidity",
      timeframe,
      status: "Resting below swing low",
      price: round(lastLow.price),
      evidence: "Swing lows are treated as observable sell-side liquidity references",
    });
  }
  const equalHigh = highs.find((pivot, index) => highs.slice(index + 1).some((other) => Math.abs(pivot.price - other.price) <= tolerance));
  const equalLow = lows.find((pivot, index) => lows.slice(index + 1).some((other) => Math.abs(pivot.price - other.price) <= tolerance));
  if (equalHigh) {
    addDetection(detections, {
      category: "liquidity",
      type: "Equal High",
      timeframe,
      status: "Confirmed",
      price: round(equalHigh.price),
      evidence: `Repeated swing highs are within ${round(tolerance)} of each other`,
    });
  }
  if (equalLow) {
    addDetection(detections, {
      category: "liquidity",
      type: "Equal Low",
      timeframe,
      status: "Confirmed",
      price: round(equalLow.price),
      evidence: `Repeated swing lows are within ${round(tolerance)} of each other`,
    });
  }
  for (const level of previousLevels(candles)) {
    addDetection(detections, {
      category: "liquidity",
      type: `${level.type} High`,
      timeframe,
      status: "Reference",
      price: round(level.high),
      evidence: "Previous period high is calculated from completed OHLC candles",
    });
    addDetection(detections, {
      category: "liquidity",
      type: `${level.type} Low`,
      timeframe,
      status: "Reference",
      price: round(level.low),
      evidence: "Previous period low is calculated from completed OHLC candles",
    });
  }
  const last = candles[candles.length - 1];
  if (lastHigh && last.high > lastHigh.price && last.close < lastHigh.price) {
    addDetection(detections, {
      category: "liquidity",
      type: "Liquidity Sweep",
      timeframe,
      status: "Buy-side swept",
      price: round(last.high),
      evidence: "Latest high ran above a prior swing high but closed back below it",
    });
  }
  if (lastLow && last.low < lastLow.price && last.close > lastLow.price) {
    addDetection(detections, {
      category: "liquidity",
      type: "Liquidity Sweep",
      timeframe,
      status: "Sell-side swept",
      price: round(last.low),
      evidence: "Latest low ran below a prior swing low but closed back above it",
    });
  }
  return detections;
}

function imbalanceDetections(candles: OHLCV[], timeframe: Timeframe): SMCDetection[] {
  const detections: SMCDetection[] = [];
  for (let index = 2; index < candles.length; index += 1) {
    const left = candles[index - 2];
    const current = candles[index];
    if (current.low > left.high) {
      addDetection(detections, {
        category: "imbalance",
        type: "Bullish FVG",
        timeframe,
        status: statusForZone(candles, index, left.high, current.low, "bullish"),
        price: round(left.high),
        price2: round(current.low),
        evidence: `Three-candle gap between ${round(left.high)} and ${round(current.low)}`,
      });
    }
    if (current.high < left.low) {
      addDetection(detections, {
        category: "imbalance",
        type: "Bearish FVG",
        timeframe,
        status: statusForZone(candles, index, current.high, left.low, "bearish"),
        price: round(current.high),
        price2: round(left.low),
        evidence: `Three-candle gap between ${round(current.high)} and ${round(left.low)}`,
      });
    }
  }
  return detections;
}

function orderBlockDetections(
  candles: OHLCV[],
  timeframe: Timeframe,
  atrValue: number,
  highs: Pivot[],
  lows: Pivot[],
): SMCDetection[] {
  const detections: SMCDetection[] = [];
  for (let index = 2; index < candles.length; index += 1) {
    const candle = candles[index];
    const body = Math.abs(candle.close - candle.open);
    if (body < atrValue * 1.5) continue;
    const priorHigh = lastPivotBefore(highs, index);
    const priorLow = lastPivotBefore(lows, index);
    const bullishBreak = priorHigh && candle.close > priorHigh.price;
    const bearishBreak = priorLow && candle.close < priorLow.price;
    if (!bullishBreak && !bearishBreak) continue;
    const direction = bullishBreak ? "bullish" : "bearish";
    const source = [...candles.slice(Math.max(0, index - 4), index)]
      .reverse()
      .find((candidate) => direction === "bullish" ? candidate.close < candidate.open : candidate.close > candidate.open);
    if (!source) continue;
    const low = Math.min(source.open, source.close, source.low);
    const high = Math.max(source.open, source.close, source.high);
    addDetection(detections, {
      category: "order_block",
      type: direction === "bullish" ? "Bullish OB" : "Bearish OB",
      timeframe,
      status: statusForZone(candles, index, low, high, direction),
      price: round(low),
      price2: round(high),
      evidence: `Last opposing candle before a ${direction} displacement break`,
    });
  }
  return detections.slice(-3);
}

function zoneDetections(
  candles: OHLCV[],
  timeframe: Timeframe,
  highs: Pivot[],
  lows: Pivot[],
  atrValue: number,
): SMCDetection[] {
  const detections: SMCDetection[] = [];
  const swingHigh = highs[highs.length - 1];
  const swingLow = lows[lows.length - 1];
  if (swingHigh) {
    addDetection(detections, {
      category: "supply_demand",
      type: "Supply zone",
      timeframe,
      status: "Observed",
      price: round(swingHigh.price - atrValue * 0.2),
      price2: round(swingHigh.price),
      evidence: "Zone is anchored to the latest confirmed swing high",
    });
    addDetection(detections, {
      category: "support_resistance",
      type: "Swing resistance",
      timeframe,
      status: "Reference",
      price: round(swingHigh.price),
      evidence: "Latest confirmed swing high",
    });
  }
  if (swingLow) {
    addDetection(detections, {
      category: "supply_demand",
      type: "Demand zone",
      timeframe,
      status: "Observed",
      price: round(swingLow.price),
      price2: round(swingLow.price + atrValue * 0.2),
      evidence: "Zone is anchored to the latest confirmed swing low",
    });
    addDetection(detections, {
      category: "support_resistance",
      type: "Swing support",
      timeframe,
      status: "Reference",
      price: round(swingLow.price),
      evidence: "Latest confirmed swing low",
    });
  }
  for (const level of previousLevels(candles)) {
    addDetection(detections, {
      category: "support_resistance",
      type: `${level.type} High`,
      timeframe,
      status: "Reference",
      price: round(level.high),
      evidence: "Completed-period resistance reference from OHLC data",
    });
    addDetection(detections, {
      category: "support_resistance",
      type: `${level.type} Low`,
      timeframe,
      status: "Reference",
      price: round(level.low),
      evidence: "Completed-period support reference from OHLC data",
    });
  }
  return detections;
}

function displacementDetections(
  candles: OHLCV[],
  timeframe: Timeframe,
  atrValue: number,
  highs: Pivot[],
  lows: Pivot[],
): SMCDetection[] {
  const detections: SMCDetection[] = [];
  for (let index = Math.max(1, candles.length - 12); index < candles.length; index += 1) {
    const candle = candles[index];
    const body = Math.abs(candle.close - candle.open);
    const priorHigh = lastPivotBefore(highs, index);
    const priorLow = lastPivotBefore(lows, index);
    const bullish = body >= atrValue * 1.5 && priorHigh && candle.close > priorHigh.price;
    const bearish = body >= atrValue * 1.5 && priorLow && candle.close < priorLow.price;
    if (bullish || bearish) {
      addDetection(detections, {
        category: "displacement",
        type: bullish ? "Bullish displacement" : "Bearish displacement",
        timeframe,
        status: "Confirmed",
        price: round(candle.close),
        evidence: `Body ${round(body)} >= 1.5 ATR ${round(atrValue)} with a structure break`,
      });
    }
  }
  return detections;
}

export function analyzeTimeframe(candles: OHLCV[], timeframe: Timeframe): TimeframeAnalysis {
  if (candles.length < 10) {
    return { timeframe, bias: "neutral", score: 50, detections: [] };
  }
  const atrValue = atr(candles);
  const structure = structureDetections(candles, timeframe, atrValue);
  const detections = [
    ...structure.detections,
    ...liquidityDetections(candles, timeframe, structure.highs, structure.lows, atrValue),
    ...imbalanceDetections(candles, timeframe),
    ...orderBlockDetections(candles, timeframe, atrValue, structure.highs, structure.lows),
    ...zoneDetections(candles, timeframe, structure.highs, structure.lows, atrValue),
    ...displacementDetections(candles, timeframe, atrValue, structure.highs, structure.lows),
  ];
  const bullish = detections.filter((detection) => /Bullish|HH|HL|Demand|support|sell-side swept/i.test(detection.type + detection.status)).length;
  const bearish = detections.filter((detection) => /Bearish|LH|LL|Supply|resistance|buy-side swept/i.test(detection.type + detection.status)).length;
  const linkedDetections = detections.map((detection) => {
    const candle = candles.reduce((closest, candidate) => {
      const candidateDistance = candidate.high < detection.price
        ? detection.price - candidate.high
        : candidate.low > detection.price
          ? candidate.low - detection.price
          : 0;
      const closestDistance = closest.high < detection.price
        ? detection.price - closest.high
        : closest.low > detection.price
          ? closest.low - detection.price
          : 0;
      return candidateDistance < closestDistance ? candidate : closest;
    }, candles[candles.length - 1]);
    return { ...detection, timestamp: candle.timestamp };
  });
  const score = Math.max(0, Math.min(100, Math.round(50 + (bullish - bearish) * 4)));
  const bias: Bias = score >= 60 ? "bullish" : score <= 40 ? "bearish" : structure.bias;
  return { timeframe, bias, score, detections: linkedDetections.slice(-40) };
}

function evidenceFor(detections: SMCDetection[], matcher: RegExp): string {
  const matches = detections.filter((detection) => matcher.test(detection.type));
  return matches.length
    ? matches.slice(-2).map((detection) => `${detection.type} (${detection.timeframe})`).join(", ")
    : "No confirmed condition";
}

export function buildSMCSignal(
  symbol: string,
  name: string,
  source: string,
  dataAsOf: Date,
  analyses: TimeframeAnalysis[],
  latest: OHLCV,
): {
  action: "BUY" | "SELL" | "WAIT";
  confidence: number;
  score: number;
  htfBias: Bias;
  entryPrice: number;
  stopLoss: number;
  takeProfit: number;
  takeProfit1: number;
  takeProfit2: number;
  riskReward: number;
  horizon: string;
  rationale: string[];
  factors: SMCScoreFactor[];
  detections: SMCDetection[];
  timeframes: TimeframeAnalysis[];
  symbol: string;
  name: string;
  source: string;
  dataAsOf: Date;
  updatedAt: Date;
} {
  const all = analyses.flatMap((analysis) => analysis.detections);
  const htf = analyses.find((analysis) => analysis.timeframe === "4H") ?? analyses[0];
  const lower = analyses.filter((analysis) => analysis.timeframe !== "4H");
  const htfBias = htf?.bias ?? "neutral";
  const bullishLower = lower.filter((analysis) => analysis.bias === "bullish").length;
  const bearishLower = lower.filter((analysis) => analysis.bias === "bearish").length;
  const bullish = (htfBias === "bullish" ? 10 : 0) + bullishLower * 5;
  const bearish = (htfBias === "bearish" ? 10 : 0) + bearishLower * 5;
  const factorDefinitions: Array<{ name: string; matcher: RegExp; bullish: number; bearish: number }> = [
    { name: "HTF alignment", matcher: /4H/, bullish: bullishLower >= 1 && htfBias === "bullish" ? 10 : 0, bearish: bearishLower >= 1 && htfBias === "bearish" ? 10 : 0 },
    { name: "Liquidity sweep", matcher: /Liquidity Sweep/, bullish: all.some((detection) => detection.type === "Liquidity Sweep" && /sell-side swept/i.test(detection.status)) ? 10 : 0, bearish: all.some((detection) => detection.type === "Liquidity Sweep" && /buy-side swept/i.test(detection.status)) ? 10 : 0 },
    { name: "MSS / CHoCH", matcher: /MSS|CHoCH/, bullish: all.some((detection) => /MSS|CHoCH/.test(detection.type) && detection.price >= latest.close) ? 10 : 0, bearish: all.some((detection) => /MSS|CHoCH/.test(detection.type) && detection.price < latest.close) ? 10 : 0 },
    { name: "BOS", matcher: /^BOS$/, bullish: all.some((detection) => detection.type === "BOS" && detection.price >= latest.close) ? 10 : 0, bearish: all.some((detection) => detection.type === "BOS" && detection.price < latest.close) ? 10 : 0 },
    { name: "FVG", matcher: /FVG/, bullish: all.some((detection) => detection.type === "Bullish FVG" && detection.status !== "Invalidated") ? 10 : 0, bearish: all.some((detection) => detection.type === "Bearish FVG" && detection.status !== "Invalidated") ? 10 : 0 },
    { name: "Order Block", matcher: /OB/, bullish: all.some((detection) => detection.type === "Bullish OB" && detection.status !== "Invalidated") ? 10 : 0, bearish: all.some((detection) => detection.type === "Bearish OB" && detection.status !== "Invalidated") ? 10 : 0 },
    { name: "Supply / Demand", matcher: /Supply|Demand/, bullish: all.some((detection) => detection.type === "Demand zone") ? 10 : 0, bearish: all.some((detection) => detection.type === "Supply zone") ? 10 : 0 },
    { name: "Support / Resistance", matcher: /support|resistance/i, bullish: all.some((detection) => /support/i.test(detection.type)) ? 10 : 0, bearish: all.some((detection) => /resistance/i.test(detection.type)) ? 10 : 0 },
    { name: "Displacement", matcher: /displacement/i, bullish: all.some((detection) => detection.type === "Bullish displacement") ? 10 : 0, bearish: all.some((detection) => detection.type === "Bearish displacement") ? 10 : 0 },
  ];
  const factorTotals = factorDefinitions.reduce((totals, factor) => ({
    bullish: totals.bullish + factor.bullish,
    bearish: totals.bearish + factor.bearish,
  }), { bullish, bearish });
  const bullishDirection = factorTotals.bullish >= factorTotals.bearish;
  const activeFactors = factorDefinitions.filter((factor) => bullishDirection ? factor.bullish > 0 : factor.bearish > 0).length;
  const totalDirectionalPoints = factorTotals.bullish + factorTotals.bearish;
  const score = totalDirectionalPoints
    ? Math.max(0, Math.min(100, Math.round((factorTotals.bullish / totalDirectionalPoints) * 100)))
    : 50;
  const hasStructureBreak = all.some((detection) => /^(BOS|CHoCH|MSS)$/.test(detection.type));
  const hasEntryZone = all.some((detection) => /FVG|OB/.test(detection.type) && detection.status !== "Invalidated");
  const hasAlignment = htfBias !== "neutral" && lower.some((analysis) => analysis.bias === htfBias);
  const hasImpulse = all.some((detection) => /displacement|Liquidity Sweep/i.test(detection.type));
  const confluenceCount = [hasStructureBreak, hasEntryZone, hasAlignment, hasImpulse].filter(Boolean).length;
  const dominantShare = totalDirectionalPoints
    ? Math.max(factorTotals.bullish, factorTotals.bearish) / totalDirectionalPoints
    : 0;
  const action = confluenceCount >= 3 && activeFactors >= 3 && dominantShare >= 0.62 && factorTotals.bullish >= 30 && bullishDirection
    ? "BUY"
    : confluenceCount >= 3 && activeFactors >= 3 && dominantShare >= 0.62 && factorTotals.bearish >= 30 && !bullishDirection
      ? "SELL"
      : "WAIT";
  const side = action === "SELL" ? "bearish" : "bullish";
  const stopDetection = all.find((detection) => side === "bullish" ? /Demand|Bullish OB|support/i.test(detection.type) : /Supply|Bearish OB|resistance/i.test(detection.type));
  const stopLoss = stopDetection?.price ?? (side === "bullish" ? latest.low : latest.high);
  const risk = Math.max(Math.abs(latest.close - stopLoss), trueRange(latest));
  const takeProfit = side === "bullish" ? latest.close + risk * 2 : latest.close - risk * 2;
  const takeProfit1 = side === "bullish" ? latest.close + risk : latest.close - risk;
  const riskReward = Number((Math.abs(takeProfit - latest.close) / Math.max(Math.abs(latest.close - stopLoss), 0.00000001)).toFixed(2));
  const factors = factorDefinitions.map((factor) => ({
    name: factor.name,
    score: bullishDirection ? factor.bullish : factor.bearish,
    maxScore: 10,
    evidence: evidenceFor(all, factor.matcher),
  }));
  const rationale = [
    `${htfBias.toUpperCase()} 4H bias with ${bullishLower + bearishLower} lower-timeframe confirmations`,
    ...factors.filter((factor) => factor.score > 0).slice(0, 3).map((factor) => `${factor.name}: ${factor.evidence}`),
    action === "WAIT" ? "Conditions are incomplete; deterministic rules return WAIT instead of forcing a side" : `Directional score is ${score}/100 with risk/reward ${riskReward}`,
  ];
  return {
    symbol,
    name,
    source,
    dataAsOf,
    action,
    confidence: action === "SELL" ? 100 - score : action === "BUY" ? score : 50,
    score,
    htfBias,
    entryPrice: round(latest.close),
    stopLoss: round(stopLoss),
    takeProfit: round(takeProfit),
    takeProfit1: round(takeProfit1),
    takeProfit2: round(takeProfit),
    riskReward,
    horizon: "Until the next confirmed structure change",
    rationale,
    factors,
    detections: all.slice(-80),
    timeframes: analyses,
    updatedAt: new Date(),
  };
}