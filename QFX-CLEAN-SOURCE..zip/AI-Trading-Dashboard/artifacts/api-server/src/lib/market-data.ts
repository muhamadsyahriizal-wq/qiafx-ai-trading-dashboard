import type { Timeframe, OHLCV } from "./smc";

export type MarketSymbol = "BTC/USDT" | "XAU/USD";

export interface MarketDefinition {
  symbol: MarketSymbol;
  name: string;
  providerSymbol: string;
  source: string;
  accent: string;
}

export interface MarketBundle {
  definition: MarketDefinition;
  candles: Record<Timeframe, OHLCV[]>;
  latest: OHLCV;
  dataAsOf: Date;
  price: number;
  change24h: number;
  volume24h: number;
}

export const MARKET_DEFINITIONS: MarketDefinition[] = [
  {
    symbol: "BTC/USDT",
    name: "Bitcoin",
    providerSymbol: "BTC-USD",
    source: "Yahoo Finance · BTC-USD",
    accent: "#f7931a",
  },
  {
    symbol: "XAU/USD",
    name: "Gold",
    providerSymbol: "GC=F",
    source: "Yahoo Finance · GC=F gold futures reference",
    accent: "#f0b90b",
  },
];

const cache = new Map<string, { expiresAt: number; value: MarketBundle }>();
const CACHE_MS = 30_000;
const HOUR_MS = 60 * 60 * 1000;

class MarketDataError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "MarketDataError";
  }
}

function finite(value: unknown): number | null {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}

function parseYahooSeries(payload: unknown): OHLCV[] {
  const result = (payload as {
    chart?: {
      result?: Array<{
        timestamp?: number[];
        indicators?: { quote?: Array<{ open?: unknown[]; high?: unknown[]; low?: unknown[]; close?: unknown[]; volume?: unknown[] }> };
      }>;
      error?: { description?: string };
    };
  })?.chart?.result?.[0];
  if (!result?.timestamp || !result.indicators?.quote?.[0]) {
    throw new MarketDataError((payload as { chart?: { error?: { description?: string } } })?.chart?.error?.description ?? "Market provider returned no OHLC data");
  }
  const quote = result.indicators.quote[0];
  const candles: OHLCV[] = [];
  for (let index = 0; index < result.timestamp.length; index += 1) {
    const open = finite(quote.open?.[index]);
    const high = finite(quote.high?.[index]);
    const low = finite(quote.low?.[index]);
    const close = finite(quote.close?.[index]);
    if (open == null || high == null || low == null || close == null) continue;
    candles.push({
      timestamp: new Date(result.timestamp[index] * 1000),
      open,
      high,
      low,
      close,
      volume: finite(quote.volume?.[index]) ?? 0,
    });
  }
  if (candles.length < 20) throw new MarketDataError("Market provider returned too few OHLC candles");
  return candles.sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
}

async function fetchYahoo(definition: MarketDefinition, interval: "1h" | "15m", range: "60d" | "5d"): Promise<OHLCV[]> {
  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(definition.providerSymbol)}?interval=${interval}&range=${range}&events=history`;
  const response = await fetch(url, {
    headers: {
      Accept: "application/json",
      "User-Agent": "Signalroom/1.0 market-data",
    },
    signal: AbortSignal.timeout(15_000),
  });
  if (!response.ok) throw new MarketDataError(`Market provider returned HTTP ${response.status}`);
  return parseYahooSeries(await response.json());
}

function resample(candles: OHLCV[], hours: number): OHLCV[] {
  const bucketMs = hours * HOUR_MS;
  const buckets = new Map<number, OHLCV[]>();
  for (const candle of candles) {
    const bucket = Math.floor(candle.timestamp.getTime() / bucketMs) * bucketMs;
    buckets.set(bucket, [...(buckets.get(bucket) ?? []), candle]);
  }
  return [...buckets.entries()]
    .sort(([left], [right]) => left - right)
    .map(([timestamp, group]) => ({
      timestamp: new Date(timestamp),
      open: group[0].open,
      high: Math.max(...group.map((candle) => candle.high)),
      low: Math.min(...group.map((candle) => candle.low)),
      close: group[group.length - 1].close,
      volume: group.reduce((sum, candle) => sum + candle.volume, 0),
    }));
}

export async function getMarketBundle(symbol: string): Promise<MarketBundle> {
  const definition = MARKET_DEFINITIONS.find((market) => market.symbol.toUpperCase() === symbol.toUpperCase());
  if (!definition) throw new MarketDataError(`Unsupported market ${symbol}`);
  const cached = cache.get(definition.symbol);
  if (cached && cached.expiresAt > Date.now()) return cached.value;

  const [hourly, fifteenMinute] = await Promise.all([
    fetchYahoo(definition, "1h", "60d"),
    fetchYahoo(definition, "15m", "5d"),
  ]);
  const oneHour = hourly.slice(-1000);
  const fifteen = fifteenMinute.slice(-500);
  const fourHour = resample(oneHour, 4).slice(-300);
  const latest = oneHour[oneHour.length - 1] ?? fifteen[fifteen.length - 1];
  const dayStart = latest.timestamp.getTime() - 24 * HOUR_MS;
  const lastDay = oneHour.filter((candle) => candle.timestamp.getTime() >= dayStart);
  const previous = lastDay[0]?.open ?? latest.open;
  const change24h = previous ? ((latest.close - previous) / previous) * 100 : 0;
  const value: MarketBundle = {
    definition,
    candles: { "4H": fourHour, "1H": oneHour.slice(-300), "15M": fifteen },
    latest,
    dataAsOf: latest.timestamp,
    price: latest.close,
    change24h,
    volume24h: lastDay.reduce((sum, candle) => sum + candle.volume, 0),
  };
  cache.set(definition.symbol, { expiresAt: Date.now() + CACHE_MS, value });
  return value;
}

export async function getAllMarketBundles(): Promise<MarketBundle[]> {
  return Promise.all(MARKET_DEFINITIONS.map((definition) => getMarketBundle(definition.symbol)));
}

export function marketFromBundle(bundle: MarketBundle) {
  return {
    symbol: bundle.definition.symbol,
    name: bundle.definition.name,
    price: Number(bundle.price.toFixed(2)),
    change24h: Number(bundle.change24h.toFixed(2)),
    volume24h: Number(bundle.volume24h.toFixed(2)),
    accent: bundle.definition.accent,
    source: bundle.definition.source,
    dataAsOf: bundle.dataAsOf,
  };
}

export { MarketDataError };